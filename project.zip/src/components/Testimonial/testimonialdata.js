export const testimonial = [
    {
        img:"assets/img/speakers/speaker-thumb-one.jpg",
        name:"Kaite Stricker",
        potision:"Web Developer"
    },
    {
        img:"assets/img/speakers/speaker-thumb-three.jpg",
        name:"Espen Brunberg",
        potision:"Designer"
    },
    {
        img:"assets/img/speakers/speaker-thumb-six.jpg",
        name:"Adam Smitha",
        potision:"full stack"
    },
    

]