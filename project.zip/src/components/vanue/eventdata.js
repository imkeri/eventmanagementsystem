
export const eventdata = [
    {
        img:"assets/img/gallery/7.jpg",
        title:"The World’s Greatest Tribute Bands on AXS TV",
        category:" 04/06/2022 at 20:00 - 22:00 on Manhattan / New York",
        price:"Tickets from $45",
        text:"Fusce pellentesque velvitae tincidunt egestas. Pellentesque habitant morbi."
    },
    {
        img:"assets/img/gallery/2.jpg",
        title:"BottleRock Napa Valley 2016",
        category:"04/08/2022 at 20:00 - 22:00 on Manhattan / New York",
        price:"Tickets from $45",
        text:"Fusce pellentesque velvitae tincidunt egestas. Pellentesque habitant morbi."
    },
    {
        img:"assets/img/gallery/3.jpg",
        title:"2016 Calgary Comic & Entertainment Expo",
        category:" 01/08/2022 at 20:00 - 22:00 on Manhattan / New York",
        price:"Tickets from $45",
        text:"Fusce pellentesque velvitae tincidunt egestas. Pellentesque habitant morbi."
    },
    {
        img:"assets/img/gallery/4.jpg",
        title:"LADIES FREE ALL NIGHT- ELLEVEN45",
        category:"11/28/2022 at 20:00 - 22:00 on Manhattan / New York",
        price:"Tickets from $45",
        text:"Fusce pellentesque velvitae tincidunt egestas. Pellentesque habitant morbi."
    },
    {
        img:"assets/img/gallery/5.jpg",
        title:"Chicago Food Truck Festival",
        category:"11/08/2022 at 20:00 - 22:00 on Manhattan / New York",
        price:"Tickets from $45",
        text:"Fusce pellentesque velvitae tincidunt egestas. Pellentesque habitant morbi."
    },
    {
        img:"assets/img/gallery/8.jpg",
        title:"2016 Calgary Comic & Entertainment Expo",
        category:" 01/08/2022 at 20:00 - 22:00 on Manhattan / New York",
        price:"Tickets from $45",
        text:"Fusce pellentesque velvitae tincidunt egestas. Pellentesque habitant morbi."
    }
]