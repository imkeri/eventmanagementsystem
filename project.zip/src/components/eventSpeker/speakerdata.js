export const  speaker=[
    {
        img:"assets/img/speakers/1.jpg",
        speakername:"Brenden Legros",
        info:"Quas alias incidunt"
    },
    {
        img:"assets/img/speakers/2.jpg",
        speakername:"Hubert Hirthe",
        info:"Consequuntur odio aut"
    },
    {
        img:"assets/img/speakers/3.jpg",
        speakername:"Cole Emmerich",
        info:"Fugiat laborum et"
    },
    {
        img:"assets/img/speakers/4.jpg",
        speakername:"Jack Christiansen",
        info:"Debitis iure vero"
    },
    {
        img:"assets/img/speakers/5.jpg",
        speakername:"Alejandrin Littel",
        info:"Qui molestiae natus"
    },
    {
        img:"assets/img/speakers/6.jpg",
        speakername:"Willow Trantow",
        info:"Non autem dicta"
    }
]